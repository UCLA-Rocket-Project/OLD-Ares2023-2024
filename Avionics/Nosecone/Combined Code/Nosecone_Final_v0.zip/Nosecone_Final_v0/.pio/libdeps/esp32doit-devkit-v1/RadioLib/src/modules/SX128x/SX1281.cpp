#include "SX1281.h"
#if !RADIOLIB_EXCLUDE_SX128X

SX1281::SX1281(Module* mod) : SX128x(mod) {

}

#endif
